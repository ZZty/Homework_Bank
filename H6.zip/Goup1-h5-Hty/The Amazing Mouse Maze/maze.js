window.onload = function() {

	 function mouse_running_style() {
	    document.getElementById("map").className = "style_change";
    }

    function mouse_locking() {
    	document.getElementById("map").className = "style_default";
    }
	
    var tip_content = document.getElementById("tip");
    function cheat() {
	    tip_content.textContent = "Don\'t cheat, you should start from the \'S\' and move to the \'E\' inside the maze!";
    }

    function win() {
	    tip_content.textContent = "You win!";
    }

    function start() {
	    tip_content.textContent = "Begin!";
    }

    var is_end = 0;	
    var walls = document.getElementsByClassName("wall"); 
    function hit_wall() {
    	for (var i = 0; i < walls.length; i++)
    		walls[i].onmouseover = function() {
    			if (!is_end) {
    			this.className = "changed_wall";
    			tip_content.textContent = "You lose!";
    			mouse_locking();
    			is_end = 1;
    		    }
    		}
    }

    function color_reduction() {
    	for (var i = 0; i < walls.length; i++)  		
    			walls[i].onmouseout = function() {
    				this.className = "wall";
    			}
    }

	document.getElementById("start_button").onmouseover = function() {
		mouse_running_style();
		start();
		is_end = 0;
		hit_wall();
		color_reduction();
		document.getElementById("end_button").onmouseover = function() {
			if(!is_end) win();
			mouse_locking();
			is_end = 1;
	    }
		document.getElementById("end_right").onmouseover = function() {
		    if(!is_end) cheat();
		    mouse_locking();
			is_end = 1;
		}
	}
}
