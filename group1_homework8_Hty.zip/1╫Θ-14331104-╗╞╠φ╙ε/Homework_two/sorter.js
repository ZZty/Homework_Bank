window.onload = function() {
	var tables = $("table");
	id_heads(tables);
	$('th').on("click", function() {
		sort(this.parentNode.parentNode.parentNode, this);
	})
}

var id_heads = function(tables) {
	var heads;
	for (var i = 0; i < tables.length; i++) {
		heads = tables[i].getElementsByTagName("th");
		for (var j = 0; j < heads.length; j++) {
			heads[j].setAttribute("id", j);
		}
	}
}

var sort = function(table_, head) {
	style_change(table_, head);
	var state = head.getAttribute("class");
	var head_id = head.getAttribute("id");
	var to_sort = new Array();
	for (var i = 1; i < table_.rows.length; i++)
		to_sort[i] = table_.rows[i];
	to_sort.sort(cmp(state, head_id));
	for (var i = 0; i < table_.rows.length-1; i++)  // Without this, reference error!
		to_sort[i] = to_sort[i].innerHTML;
	for (var i = 0; i < table_.rows.length - 1; i++)
		table_.rows[i + 1].innerHTML = to_sort[i];
}

var cmp = function(state, head_id) {
	return function(row_a, row_b) {
		var v1 = row_a.cells[head_id].innerHTML;
		var v2 = row_b.cells[head_id].innerHTML;
		if (v1 < v2) {
			return state == "odd_click" ? -1: 1;
		} else if (v1 > v2) {
			return state == "odd_click" ? 1: -1;
		} else return 0;
	}
}

var style_change = function(table_, head) {
	var state = head.getAttribute("class");
	for (var i = 0; i < table_.rows[0].cells.length; i++)
		table_.rows[0].cells[i].setAttribute("class", "");
	if (state != "odd_click")
		head.setAttribute("class", "odd_click");
	else head.setAttribute("class", "even_click");
}
