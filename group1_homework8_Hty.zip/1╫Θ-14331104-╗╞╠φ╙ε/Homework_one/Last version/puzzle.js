window.onload = function() {
	var is_end = 1;

    var disorder = function() {
    	var temp, index, arr = [17], id_;
    	for (var i = 1; i <= 16; i++)
    		arr[i] = i;
    	for (var i = 1; i < 16; i++) {
    		index = parseInt(Math.random() * (16 - i)) + i;
    		if (index != i) {
    			temp = arr[i];
    			arr[i] = arr[index];
    			arr[index] = temp;
    		}
    	}
    	for (var i = 1; i <= 16; i++) {
    		id_ = to_id(arr[i]);
    		document.getElementById(id_).className = to_class(i);
    	}
    }

    var move = function(i) {
    	var id_ = to_id(i), n1, n2;
    	n1 = parseInt(document.getElementById(id_).className.substr(-2));
    	n2 = parseInt(document.getElementById('pic_16').className.substr(-2));
    	if (beside(n1, n2)) {
    		exchange(i);
    	}
    }

	var judge = function() {
		var id_, id_number, class_number, flag = 1;
		for (var i = 1; i <= 16; i++) {
			id_ = to_id(i);
			id_number = id_.substr(-2);
			class_number = document.getElementById(id_).className.substr(-2);
			if (id_number != class_number)
				flag = 0;
		}
		if (flag) {
			is_end = 1;
		    alert("You win");
		}
	}

	var to_id = function(n) {
		if (n < 10)
			return 'pic_0' + n;
		else return 'pic_' + n;
	}

	var to_class = function(n) {
		if (n < 10)
			return 'panda p_0' + n;
		else return 'panda p_' + n;
	}

	var beside = function(a, b) {  // To judge two images are beside each other or not.
		if (a - b === 4 || a - b === -4)
			return 1;
		if (a - b === 1 && a != 5 && a != 9 && a != 13)
			return 1;
		if (b - a === 1 && b != 5 && b != 9 && b != 13)
			return 1;
		return 0;

	}

	var exchange = function(a) {
		var id_1 = to_id(a), class_1, class_2;
		class_1 = document.getElementById(id_1).className;
		class_2 = document.getElementById("pic_16").className;
		document.getElementById(id_1).className = class_2;
		document.getElementById("pic_16").className = class_1;
	}

	document.getElementById('button').onclick = function() {
		is_end = 0;
		disorder();
		judge();          // In case of that all the images are at place at the beginning;
		var images = document.getElementsByClassName('panda');
		for (var i = 0; i < images.length; i++)
			images[i].onclick = function(i) {
				return function() {
					if (!is_end) {
					    move(i + 1);
					    judge();
				    }
				}
			} (i);
	}
}