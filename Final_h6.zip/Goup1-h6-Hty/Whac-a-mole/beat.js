window.onload = function() {
	var second = 30;
	var timer;
	var goal = 0;
	var is_end = 1;
	var random_number;
	var index;
	var pits = document.getElementsByClassName('pit');

	function time_count() {
		document.getElementById('time').value = second;
		second -= 1;
		if (second >= 0)
		    timer = setTimeout(time_count, 1000);
		else {
			stop();
		}
	}

    function new_pit() {
    	random_number = Math.floor(Math.random()*60);
    	index = '' + random_number;
        document.getElementById(index).className += ' hit_pit';
    }

    function style_reset() {
    	index = '' + random_number;
    	document.getElementById(index).className = 'pit';
    }

    function print() {
    	var s = "Game Over." + "\n" + "Your score is: " + goal + '.' + '\n';
    	if (goal < 0)
    		s += 'Are you kidding me?';
    	else if (goal == 0)
    		s += 'Have you falled asleep?';
    	else if (goal < 21)
    		s += 'Even Mr Wang plays better than you~';
    	else s += 'You are crazy baby!';
    	alert(s);
    }

    function stop() {
    	is_end = 1;
    	clearTimeout(timer);
    	second = 0;
    	document.getElementById('time').value = second;
    	document.getElementById('process').value = 'Game Over';
    	style_reset();
    	print();
    }

	document.getElementById('switch').onclick = function() {
		if (is_end) {
			is_end = 0;
			document.getElementById('process').value = 'Playing';
			goal = 0;
			document.getElementById('score').value = goal;
			second = 30;
			time_count();
			new_pit();
			for (var i = 0; i < pits.length; i++) {
				pits[i].onclick = function() {
					if (!is_end) {
					    if (this.id == random_number) {
						    goal += 1;
						    document.getElementById('score').value = goal;
						    style_reset();
						    new_pit();
					    } else {
						    goal -= 1;
						    document.getElementById('score').value = goal;
					    }
					}
				}
			} // for cycle
		} else {
			stop();
		}
	} // for switch
}