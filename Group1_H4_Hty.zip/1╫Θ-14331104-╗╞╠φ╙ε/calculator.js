var clear_flag = false;

function get_num(num) {
	if (clear_flag) {
		clear();
		clear_flag = false;
	}
	var print = document.getElementById("screen");
	print.value += num;
}

function get_result() {
	clear_flag = true;
	var s = document.getElementById("screen");
	try {
		eval(s.value);
	}
	catch (expection) {
		s.value = "Invalib Input!";
	}
	if (eval(s.value) === Infinity)
		s.value = "Invalib Input!";
	else s.value = s.value + '=' + eval(s.value).toFixed(3);
}

function pop() {
	var s = document.getElementById("screen");
	if (s.value.length > 0)
		s.value = s.value.substring(0, s.value.length - 1)
}

function clear() {
	var print = document.getElementById("screen");
	print.value = '';
}

window.onload = function() {
	document.getElementById("number_0").onclick = function() {
		get_num(0);
	}
	document.getElementById("number_1").onclick = function() {
		get_num(1);
	}
	document.getElementById("number_2").onclick = function() {
		get_num(2);
	}
	document.getElementById("number_3").onclick = function() {
		get_num(3);
	}
	document.getElementById("number_4").onclick = function() {
		get_num(4);
	}
	document.getElementById("number_5").onclick = function() {
		get_num(5);
	}
	document.getElementById("number_6").onclick = function() {
		get_num(6);
	}
	document.getElementById("number_7").onclick = function() {
		get_num(7);
	}
	document.getElementById("number_8").onclick = function() {
		get_num(8);
	}
	document.getElementById("number_9").onclick = function() {
		get_num(9);
	}
	document.getElementById("point").onclick = function() {
		get_num('.');
	}
	document.getElementById("operator_left").onclick = function() {
		get_num('(');
	}
	document.getElementById("operator_right").onclick = function() {
		get_num(')');
	}
	document.getElementById("divise").onclick = function() {
		get_num('/');
	}	
	document.getElementById("multiply").onclick = function() {
		get_num('*');
	}
	document.getElementById("plus").onclick = function() {
		get_num('+');
	}
    document.getElementById("subtrace").onclick = function() {
		get_num('-');
	}
	document.getElementById("ce").onclick = function() {
		clear();
	}
	document.getElementById("pop").onclick = function() {
		pop();
	}
	document.getElementById("result").onclick = function() {
		get_result();
	}
}
